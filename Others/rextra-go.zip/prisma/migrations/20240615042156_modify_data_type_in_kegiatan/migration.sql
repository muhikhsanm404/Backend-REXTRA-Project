-- AlterTable
ALTER TABLE `kegiatan` MODIFY `deskripsi` TEXT NOT NULL,
    MODIFY `persyaratan` LONGTEXT NOT NULL,
    MODIFY `skill` LONGTEXT NOT NULL;
